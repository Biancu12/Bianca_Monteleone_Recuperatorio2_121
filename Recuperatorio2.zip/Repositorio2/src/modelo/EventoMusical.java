package modelo;

import java.time.LocalDate;

public class EventoMusical extends Evento implements Comparable<EventoMusical>{

    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    @Override
    public String toString() {
        return "EventoMusical{" + "id=" + getId() + ", nombre=" + getNombre() + ", fecha=" + getFecha() + ", artista=" + artista + ", genero=" + genero + '}';
    }

    @Override
    public int compareTo(EventoMusical o) {
        return this.getFecha().compareTo(o.getFecha());
    }

    @Override
    public String toCSV() {
        return getId() + "," + getNombre() + "," + getFecha().toString() + "," + artista + "," + genero;
    }

    public static EventoMusical fromCSV(String eventoCSV) {
        if (eventoCSV.endsWith("\n")) {
            eventoCSV = eventoCSV.substring(0, eventoCSV.length() - 1);
        }
        String[] valores = eventoCSV.split(",");
        return new EventoMusical(Integer.parseInt(valores[0]),
                valores[1],
                LocalDate.parse(valores[2]),
                valores[3],
                GeneroMusical.valueOf(valores[4]));
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    public String getArtista() {
        return artista;
    }

}
