package recuperatorio2;

import config.AppConstants;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import modelo.EventoMusical;
import modelo.GeneroMusical;
import servicio.GestorEventos;

public class Test {

    public static void main(String[] args) {
        // Crear instancia del gestor de eventos
        GestorEventos<EventoMusical> gestor = new GestorEventos<>();

        // Crear algunos eventos musicales
        gestor.agregar(new EventoMusical(1, "Rock Fest", LocalDate.of(2024, 8, 5),
                "Queen Revival", GeneroMusical.ROCK));
        gestor.agregar(new EventoMusical(2, "Jazz Night", LocalDate.of(2024, 6, 20),
                "John Doe Quintet", GeneroMusical.JAZZ));
        gestor.agregar(new EventoMusical(3, "Pop Party", LocalDate.of(2024, 3, 15),
                "Taylor Tribute", GeneroMusical.POP));
        gestor.agregar(new EventoMusical(4, "Electronic Vibes", LocalDate.of(2024, 10,
                12), "DJ Nova", GeneroMusical.ELECTRONICA));

        // Mostrar todos los eventos
        System.out.println("Lista inicial de eventos:");
        gestor.mostrarTodos();

        // Eliminar evento
        separador();
        System.out.println("Eliminando el evento en el indice 2...");
        gestor.eliminar(2);
        gestor.mostrarTodos();

        //Buscar evento
        separador();
        System.out.println("Buscando el evento en el indice 0...");
        System.out.println(gestor.obtener(0));

        // Ordenar por fecha (orden natural)
        separador();
        System.out.println("Eventos ordenados por fecha:");
        gestor.ordenar();
        gestor.mostrarTodos();

        // Ordenar por nombre de evento
        separador();
        System.out.println("Eventos ordenados por nombre:");
        gestor.ordenar(Comparator.comparing(EventoMusical::getNombre));
        gestor.mostrarTodos();

        // Filtrar por género
        separador();
        System.out.println("Eventos de genero ROCK:");
        List<EventoMusical> rockEvents = gestor.filtrar(e -> e.getGenero().equals(GeneroMusical.ROCK));
        rockEvents.forEach(System.out::println);

        // Filtrar por palabra clave en el nombre
        separador();
        System.out.println("Eventos que contienen 'Night' en el nombre:");
        List<EventoMusical> nightEvents = gestor.filtrar(e -> e.getNombre().contains("Night"));
        nightEvents.forEach(System.out::println);

        // Buscar por rango de fechas
        separador();
        System.out.println("Eventos entre el 01/01/2024 y el 31/07/2024:");
        List<EventoMusical> dateRangeEvents = gestor.buscarPorRango(
                LocalDate.of(2024, 1, 1),
                LocalDate.of(2024, 7, 31)
        );
        dateRangeEvents.forEach(System.out::println);

        // Guardar y cargar en formato binario
        separador();
        System.out.println("Guardando y cargando eventos en binario...");
        gestor.serializar(AppConstants.SERIAL.toString());
        gestor.limpiar(); // Vaciar el gestor
        gestor.deserealizar(AppConstants.SERIAL.toString());
        gestor.mostrarTodos();

        // Guardar y cargar en formato CSV
        separador();
        System.out.println("Guardando y cargando eventos en CSV...");
        gestor.guardarCSV(AppConstants.CSV.toString());
        gestor.limpiar(); // Vaciar el gestor
        gestor.cargarCSV(AppConstants.CSV.toString(), linea
                -> EventoMusical.fromCSV(linea));
        gestor.mostrarTodos();

        // Filtro dinámico usando Predicate
        separador();
        System.out.println("Filtrar eventos dinamicamente (artista contiene 'DJ'):");
        Predicate<EventoMusical> filtroArtista = (e -> e.getArtista().contains("DJ"));
        List<EventoMusical> filtroDinamico = gestor.filtrar(filtroArtista);
        filtroDinamico.forEach(System.out::println);
    }

    public static void separador() {
        System.out.println("....................................................................................................");
    }

}
