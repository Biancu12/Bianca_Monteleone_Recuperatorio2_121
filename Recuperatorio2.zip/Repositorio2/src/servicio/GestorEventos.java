package servicio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import modelo.Evento;

public class GestorEventos<T extends Evento> {

    private List<T> eventos = new LinkedList<>();

    public void mostrarTodos() {
        for (T item : eventos) {
            System.out.println(item);
        }
    }

    public void agregar(T item) {
        if (item == null) {
            throw new IllegalArgumentException("Esta lista no almacena nulos");
        }
        eventos.add(item);
    }

    public T obtener(int indice) {
        validarIndice(indice);
        return eventos.get(indice);
    }

    public void eliminar(int indice) {
        validarIndice(indice);
        eventos.remove(indice);
    }

    public List<T> filtrar(Predicate<T> predicado) {
        List<T> aux = new LinkedList<>();
        for (T item : eventos) {
            if (predicado.test(item)) {
                aux.add(item);
            }
        }
        return aux;
    }

    public List<T> buscarPorRango(LocalDate fechaInicio, LocalDate fechaFin) {
        List<T> eventosFiltrados = new ArrayList<>();
        for (T item : eventos) {
            LocalDate fechaEvento = item.getFecha();
            if (fechaEvento.compareTo(fechaInicio) >= 0 && fechaEvento.compareTo(fechaFin) <= 0) {
                eventosFiltrados.add(item);
            }
        }
        return eventosFiltrados;
    }

    public void ordenar() {
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    public void ordenar(Comparator<T> comparador) {
        eventos.sort(comparador);
    }

    public void serializar(String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(eventos);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public List<T> deserealizar(String path) {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            eventos = (List<T>) input.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
        return eventos;
    }

    public void guardarCSV(String path) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write("id,nombre,fecha,artista,genero\n");
            for (T item : eventos) {
                bw.write(item.toCSV() + "\n");
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void cargarCSV(String path, Function<String, T> funcion) {
        eventos.clear();
        try (BufferedReader bf = new BufferedReader(new FileReader(path))) {
            String linea;
            bf.readLine();
            while ((linea = bf.readLine()) != null) {
                eventos.add(funcion.apply(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("Error en archivo");
        }
    }

    public void limpiar() {
        eventos.clear();
    }

    private void validarIndice(int indice) {
        if (indice < 0 || indice >= eventos.size()) {
            throw new IndexOutOfBoundsException("El item no esta en la lista");
        }
    }
}
